using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.HomeCliente
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
