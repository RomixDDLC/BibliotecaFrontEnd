using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.Libro
{
    public class RentarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
