using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.Auth
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
