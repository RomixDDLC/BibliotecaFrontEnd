using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.Entrega
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
