using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.Entrega
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
