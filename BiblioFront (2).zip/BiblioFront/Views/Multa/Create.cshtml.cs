using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.Multa
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
