using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTEST.Views.Multa
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
