﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVCTEST.Models;
using MVCTEST.Services;
using System.Threading.Tasks;
using System.Linq;

namespace MVCTEST.Controllers
{
    public class PrestamoController : Controller
    {
        private readonly PrestamoService _service;
        private readonly ClienteService _clienteService;
        private readonly LibroService _libroService;
        private readonly EmpleadoService _empleadoService;

        public PrestamoController(PrestamoService service, ClienteService clienteService, LibroService libroService, EmpleadoService empleadoService)
        {
            _service = service;
            _clienteService = clienteService;
            _libroService = libroService;
            _empleadoService = empleadoService;
        }

        public async Task<IActionResult> Index()
        {
            var prestamos = await _service.ObtenerPrestamos();
            return View(prestamos);
        }

        public async Task<IActionResult> Create()
        {
            if (HttpContext.Session.GetString("Rol") != "Empleado")
                return Unauthorized();

            await CargarListasDropdown();

            var dto = new PrestamoDto
            {
                FechaPrestamo = DateTime.Today,
                FechaLimite = DateTime.Today.AddDays(15),
                Estado = "Activo"       // <-- valor inicial
            };
            await CargarListasDropdown(dto);
            return View(dto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PrestamoDto dto)
        {
            if (HttpContext.Session.GetString("Rol") != "Empleado")
                return Unauthorized();

            if (!ModelState.IsValid)
            {
                await CargarListasDropdown(dto);
                return View(dto);
            }

            var empleadoId = HttpContext.Session.GetInt32("EmpleadoID");
            if (empleadoId == null)
            {
                ModelState.AddModelError("", "No se pudo obtener el ID del empleado desde la sesión.");
                await CargarListasDropdown();
                return View(dto);
            }

            var createDto = new PrestamoCreateDto
            {
                ClienteID = dto.ClienteID,
                LibroID = dto.LibroID,
                EmpleadoID = empleadoId.Value,
                FechaPrestamo = dto.FechaPrestamo,
                FechaLimite = dto.FechaLimite,
                FechaDevuelto = dto.FechaDevuelto,
                Estado = dto.Estado,
                TotalMulta = dto.TotalMulta,
                MultaID = dto.MultaID,
                EntregaID = dto.EntregaID
            };

            var creado = await _service.CrearPrestamo(createDto);
            if (creado)
            return RedirectToAction("Index");

            ModelState.AddModelError("", "No se pudo crear el préstamo.");
            await CargarListasDropdown();
            return View(dto);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (HttpContext.Session.GetString("Rol") != "Empleado")
                return Unauthorized();

            var eliminado = await _service.EliminarPrestamo(id);
            if (!eliminado)
            {
                TempData["Error"] = "No se pudo eliminar el préstamo.";
            }

            return RedirectToAction(nameof(Index));
        }

        private async Task CargarListasDropdown(PrestamoDto dto = null)
        {
            var clientes = await _clienteService.ObtenerClientes();
            ViewBag.Clientes = new SelectList(
                clientes.Select(c => new {
                    c.ClienteID,
                    NombreCompleto = $"{c.Nombre} {c.Apellido}"
                }),
                "ClienteID", "NombreCompleto",
                dto?.ClienteID
            );

            var libros = await _libroService.ObtenerLibros();
            ViewBag.Libros = new SelectList(libros, "LibroID", "Titulo", dto?.LibroID);

            ViewBag.Estados = new List<SelectListItem>
    {
        new SelectListItem{ Value = "Activo", Text = "Activo", Selected = dto?.Estado=="Activo" },
        new SelectListItem{ Value = "Devuelto", Text = "Devuelto", Selected = dto?.Estado=="Devuelto" },
        new SelectListItem{ Value = "Pendiente", Text = "Pendiente", Selected = dto?.Estado=="Pendiente" }
    };
        }

        public async Task<IActionResult> Edit(int id)
        {
            var prestamo = await _service.ObtenerPrestamoPorId(id);
            if (prestamo == null)
                return NotFound();

            await CargarListasDropdown();
            return View(prestamo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, PrestamoDto dto)
        {
            if (id != dto.PrestamoID)
                return BadRequest();

            if (!ModelState.IsValid)
            {
                await CargarListasDropdown();
                return View(dto);
            }

            var actualizado = await _service.ActualizarPrestamo(dto);
            if (!actualizado)
            {
                ModelState.AddModelError("", "No se pudo actualizar el préstamo.");
                await CargarListasDropdown();
                return View(dto);
            }

            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Details(int id)
        {
            var prestamo = await _service.ObtenerPrestamoPorId(id);
            if (prestamo == null)
                return NotFound();

            return View(prestamo);
        }

    }
}
