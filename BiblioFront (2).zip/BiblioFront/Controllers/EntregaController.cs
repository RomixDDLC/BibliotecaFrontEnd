﻿using Microsoft.AspNetCore.Mvc;
using MVCTEST.Models;
using MVCTEST.Services;

namespace MVCTEST.Controllers
{
    public class EntregaController : Controller
    {
        private readonly EntregaService _service;

        // Inyección del servicio vía constructor
        public EntregaController(EntregaService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var entregas = await _service.ObtenerEntregas();
            return View(entregas);
        }

        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("Rol") != "Empleado")
                return Unauthorized();

            return View();
        }

        [HttpPost]
        [HttpPost]
        public async Task<IActionResult> Create(EntregaCreateDto dto)
        {
            var creada = await _service.CrearEntrega(dto);
            if (creada)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "Error al crear la entrega.");
            return View(dto);
        }
        public async Task<IActionResult> Details(int id)
        {
            var entrega = await _service.ObtenerEntregaPorId(id);
            if (entrega == null)
                return NotFound();

            return View(entrega);
        }
        public async Task<IActionResult> Edit(int id)
        {
            var entrega = await _service.ObtenerEntregaPorId(id);
            if (entrega == null)
                return NotFound();

            return View(entrega);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(EntregaDto dto)
        {
            var actualizado = await _service.ActualizarEntrega(dto);
            if (actualizado)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "Error al actualizar la entrega.");
            return View(dto);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var eliminado = await _service.EliminarEntrega(id);
            if (eliminado)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "Error al eliminar la entrega.");
            var entregas = await _service.ObtenerEntregas();
            return View("Index", entregas);
        }


    }
}
