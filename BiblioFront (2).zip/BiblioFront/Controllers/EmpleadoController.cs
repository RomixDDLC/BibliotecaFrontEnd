﻿using Microsoft.AspNetCore.Mvc;
using MVCTEST.Models;
using MVCTEST.Services;

namespace MVCTEST.Controllers
{
    public class EmpleadoController : Controller
    {
        private readonly EmpleadoService _service;

        public EmpleadoController(EmpleadoService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var empleados = await _service.ObtenerEmpleados();
            return View(empleados);
        }

        // GET: Empleado/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Empleado/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmpleadoDto dto)
        {
            if (!ModelState.IsValid)
                return View(dto);

            await _service.CrearEmpleado(dto);
            return RedirectToAction("Index");
        }

        // GET: Empleado/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var empleado = await _service.ObtenerEmpleadoPorId(id);
            if (empleado == null)
                return NotFound();

            return View(empleado);
        }

        // POST: Empleado/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, EmpleadoDto dto)
        {
            if (!ModelState.IsValid)
                return View(dto);

            if (string.IsNullOrWhiteSpace(dto.ContrasenaHash))
                dto.ContrasenaHash = null;

            var success = await _service.ActualizarEmpleado(id, dto);
            if (!success)
                return BadRequest();

            return RedirectToAction("Index");
        }

        // GET: Empleado/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var empleado = await _service.ObtenerEmpleadoPorId(id);
            if (empleado == null)
                return NotFound();

            return View(empleado);
        }

        // ✅ GET: Empleado/Delete/5 (confirma eliminación)
        public async Task<IActionResult> Delete(int id)
        {
            var empleado = await _service.ObtenerEmpleadoPorId(id);
            if (empleado == null)
                return NotFound();

            return View(empleado); // Vista Delete.cshtml
        }

        // ✅ POST: Empleado/Delete/5 (elimina el registro)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var success = await _service.EliminarEmpleado(id);
            if (!success)
                return BadRequest();

            return RedirectToAction("Index");
        }
    }
}
