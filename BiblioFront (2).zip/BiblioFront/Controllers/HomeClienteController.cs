﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MVCTEST.Services;
using System.Threading.Tasks;
using System.Linq;

namespace MVCTEST.Controllers
{
    public class HomeClienteController : Controller
    {
        private readonly LibroService _libroService;
        private readonly PrestamoService _prestamoService;

        public HomeClienteController(LibroService libroService, PrestamoService prestamoService)
        {
            _libroService = libroService;
            _prestamoService = prestamoService;
        }

        public async Task<IActionResult> Index()
        {
            var usuario = HttpContext.Session.GetString("Usuario");
            var clienteId = HttpContext.Session.GetInt32("ClienteID");

            if (string.IsNullOrEmpty(usuario) || clienteId == null)
                return RedirectToAction("Login", "Auth");

            var libros = await _libroService.ObtenerLibrosDisponibles();

            // Obtener préstamos pendientes del cliente
            var prestamos = await _prestamoService.ObtenerPrestamosPorCliente(clienteId.Value);
            var prestamosPendientes = prestamos
                .Where(p => p.Estado != "Devuelto" && p.FechaDevuelto == null)
                .ToList();

            ViewBag.Usuario = usuario;
            ViewBag.ClienteID = clienteId;
            ViewBag.PrestamosPendientes = prestamosPendientes;

            return View(libros); // Vista: Views/HomeCliente/Index.cshtml
        }
    }
}
