﻿using Microsoft.AspNetCore.Mvc;
using MVCTEST.Models;
using MVCTEST.Services;

namespace MVCTEST.Controllers
{
    public class MultaController : Controller
    {
        private readonly MultaService _service;

        public MultaController(MultaService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var multas = await _service.ObtenerMultas();
            return View(multas);
        }

        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("Rol") != "Empleado")
                return Unauthorized();

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(MultaDto dto)
        {
            var creado = await _service.CrearMulta(dto);
            if (creado)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "No se pudo crear la multa.");
            return View(dto);
        }

        // GET: Multa/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var multa = await _service.ObtenerMultaPorId(id);
            if (multa == null)
                return NotFound();

            return View(multa);
        }

        // POST: Multa/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, MultaDto dto)
        {
            if (id != dto.MultaID)
                return BadRequest();

            if (!ModelState.IsValid)
                return View(dto);

            var resultado = await _service.ActualizarMulta(id, dto);
            if (resultado)
                return RedirectToAction(nameof(Index));

            ModelState.AddModelError("", "No se pudo actualizar la multa.");
            return View(dto);
        }

        // POST: Multa/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var eliminado = await _service.EliminarMulta(id);
            if (!eliminado)
                return BadRequest();

            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Details(int id)
        {
            var multa = await _service.ObtenerMultaPorId(id);
            if (multa == null)
                return NotFound();

            return View(multa);
        }

    }
}
