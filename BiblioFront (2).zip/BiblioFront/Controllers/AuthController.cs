﻿using Microsoft.AspNetCore.Mvc;
using MVCTEST.Models;
using MVCTEST.Services;
using MVCTEST.Services.Frontend_MVC.Services;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace MVCTEST.Controllers
{
    public class AuthController : Controller
    {
        private readonly EmpleadoService _empleadoService;
        private readonly ClienteLoginService _clienteLoginService;

        public AuthController(EmpleadoService empleadoService, ClienteLoginService clienteLoginService)
        {
            _empleadoService = empleadoService;
            _clienteLoginService = clienteLoginService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // Validar empleados
            var empleados = await _empleadoService.ObtenerEmpleados();

            var usuarioEmpleado = empleados.FirstOrDefault(e =>
                e.Usuario == model.Usuario && e.ContrasenaHash == model.Contrasena);

            if (usuarioEmpleado != null)
            {
                HttpContext.Session.SetString("Rol", usuarioEmpleado.Rol);
                HttpContext.Session.SetString("Usuario", usuarioEmpleado.Usuario);
                HttpContext.Session.SetInt32("EmpleadoID", usuarioEmpleado.EmpleadoID);
                // Podrías añadir un flag para diferenciar empleado de cliente
                HttpContext.Session.SetString("TipoUsuario", "Empleado");

                return RedirectToAction("Index", "Home");
            }

            // Validar clientes (usuario = correo, contraseña = teléfono)
            var cliente = await _clienteLoginService.ValidarClienteAsync(model.Usuario, model.Contrasena);

            if (cliente != null)
            {
                HttpContext.Session.SetString("Rol", "Cliente");
                HttpContext.Session.SetString("Usuario", cliente.Correo);
                HttpContext.Session.SetInt32("ClienteID", cliente.ClienteID);
                HttpContext.Session.SetString("TipoUsuario", "Cliente");

                return RedirectToAction("Index", "HomeCliente"); // O donde manejes clientes
            }

            ViewBag.Mensaje = "Error: usuario o contraseña incorrectos";
            return View(model);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
