﻿using Microsoft.AspNetCore.Mvc;
using MVCTEST.Models;
using MVCTEST.Services;

namespace MVCTEST.Controllers
{
    public class LibroController : Controller
    {
        private readonly LibroService _service;

        public LibroController(LibroService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var libros = await _service.ObtenerLibros();
            return View(libros);
        }

        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("Rol") != "Empleado")
                return Unauthorized();

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(LibroDto dto)
        {
            var creado = await _service.CrearLibro(dto);
            if (creado)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "Error al crear el libro.");
            return View(dto);
        }
        // GET: Libro/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var libro = await _service.ObtenerLibroPorId(id);
            if (libro == null)
                return NotFound();

            return View(libro);
        }

        // POST: Libro/Edit/5
        [HttpPost]
        public async Task<IActionResult> Edit(int id, LibroDto dto)
        {
            if (id != dto.LibroID)
                return BadRequest();

            var actualizado = await _service.ActualizarLibro(id, dto);
            if (actualizado)
                return RedirectToAction("Index");

            ModelState.AddModelError("", "Error al actualizar el libro.");
            return View(dto);
        }
        // GET: Libro/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var libro = await _service.ObtenerLibroPorId(id);
            if (libro == null)
                return NotFound();

            return View(libro);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var eliminado = await _service.EliminarLibro(id);
            if (eliminado)
                return RedirectToAction(nameof(Index));

            return Problem("Error al eliminar el libro.");
        }


        

    }
}
