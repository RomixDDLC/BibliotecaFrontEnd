﻿namespace MVCTEST.Models
{
    public class EntregaDto
    {
        public int EntregaID { get; set; }
        public string MetodoEntrega { get; set; }
    }
}
