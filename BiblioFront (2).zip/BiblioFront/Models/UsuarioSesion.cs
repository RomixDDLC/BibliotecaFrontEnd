﻿namespace MVCTEST.Models
{

    public class UsuarioSesion
    {
        public string Usuario { get; set; }
        public string Rol { get; set; }
        public string Nombre { get; set; }
    }

}


