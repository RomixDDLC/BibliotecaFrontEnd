﻿namespace MVCTEST.Models
{
    // Models/EntregaCreateDto.cs
        public class EntregaCreateDto
        {
            public string MetodoEntrega { get; set; }
        }
    
}
