﻿using System.ComponentModel.DataAnnotations;

namespace MVCTEST.Models
{
    public class LibroDto
    {
        public int LibroID { get; set; }

        [Required]
        public string Titulo { get; set; }

        [Required]
        public string Autor { get; set; }

        public string Editorial { get; set; }

        public string Isbn { get; set; }

        [Display(Name = "Año Publicación")]
        public int AñoPublicacion { get; set; }

        public string Genero { get; set; }

        public int EjemplaresDisponibles { get; set; }
    }
}
