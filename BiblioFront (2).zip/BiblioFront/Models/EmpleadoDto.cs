﻿namespace MVCTEST.Models
{
    public class EmpleadoDto
    {
        public int EmpleadoID { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Usuario { get; set; }
        public string Rol { get; set; }
        public DateTime FechaIngreso { get; set; }

        // Agrega esta propiedad para la contraseña
        public string? ContrasenaHash { get; set; }
    }

}
