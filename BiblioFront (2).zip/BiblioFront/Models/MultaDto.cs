﻿namespace MVCTEST.Models
{
    public class MultaDto
    {
        public int MultaID { get; set; }
        public int DiasAtraso { get; set; }
        public decimal PrecioPorDia { get; set; }

        // Calculado: Monto total de la multa
        public decimal MontoTotal => DiasAtraso * PrecioPorDia;

        // Opcional: si quieres mostrar detalles del préstamo asociado
        public int? PrestamoID { get; set; } // Si decides agregarlo
    }
}
