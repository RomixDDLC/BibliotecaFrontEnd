﻿namespace MVCTEST.Models
{
  
        public class LoginViewModel
        {
            public string Usuario { get; set; }
            public string Contrasena { get; set; }
        }
    }


