﻿namespace MVCTEST.Models
{
    public class PrestamoDto
    {
        public int PrestamoID { get; set; }  // ✅ ID del préstamo
        public int LibroID { get; set; }
        public int ClienteID { get; set; }
        public int EmpleadoID { get; set; }
        public string EmpleadoNombre { get; set; } // Asegúrate de que esté incluida

        public DateTime FechaPrestamo { get; set; }
        public DateTime FechaLimite { get; set; }
        public DateTime? FechaDevuelto { get; set; }
        public string Estado { get; set; }
        public decimal TotalMulta { get; set; }
        public int? MultaID { get; set; }
        public int? EntregaID { get; set; }

        public string ClienteNombre { get; set; }
        public string LibroTitulo { get; set; }

    }
}
