﻿using MVCTEST.Models;
using System.Net.Http;
using System.Net.Http.Json;

namespace MVCTEST.Services
{
    public class ClienteService
    {
        private readonly HttpClient _http;

        public ClienteService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<ClienteDto>> ObtenerClientes()
        {
            return await _http.GetFromJsonAsync<List<ClienteDto>>("clientes");
        }

        public async Task<bool> CrearCliente(ClienteDto dto)
        {
            var response = await _http.PostAsJsonAsync("clientes", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<ClienteDto?> ObtenerClientePorId(int id)
        {
            return await _http.GetFromJsonAsync<ClienteDto>($"clientes/{id}");
        }

        public async Task<bool> ActualizarCliente(int id, ClienteDto dto)
        {
            var response = await _http.PutAsJsonAsync($"clientes/{id}", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarCliente(int id)
        {
            var response = await _http.DeleteAsync($"clientes/{id}");
            return response.IsSuccessStatusCode;
        }
    }
}