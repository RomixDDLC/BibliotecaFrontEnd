﻿using MVCTEST.Models;
using System.Net.Http.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MVCTEST.Services
{
    public class LibroService
    {
        private readonly HttpClient _httpClient;

        public LibroService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<LibroDto>> ObtenerLibros()
        {
            return await _httpClient.GetFromJsonAsync<List<LibroDto>>("libros") ?? new List<LibroDto>();
        }

        public async Task<bool> CrearLibro(LibroDto dto)
        {
            var response = await _httpClient.PostAsJsonAsync("libros", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<LibroDto?> ObtenerLibroPorId(int id)
        {
            return await _httpClient.GetFromJsonAsync<LibroDto>($"libros/{id}");
        }

        public async Task<bool> EliminarLibro(int id)
        {
            var response = await _httpClient.DeleteAsync($"libros/{id}");
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ActualizarLibro(int id, LibroDto dto)
        {
            var response = await _httpClient.PutAsJsonAsync($"libros/{id}", dto);
            return response.IsSuccessStatusCode;
        }
        public async Task<List<LibroDto>> ObtenerLibrosDisponibles()
        {
            return await _httpClient.GetFromJsonAsync<List<LibroDto>>("libros/disponibles") ?? new List<LibroDto>();
        }

    }
}
