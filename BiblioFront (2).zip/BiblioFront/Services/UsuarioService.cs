﻿using MVCTEST.Models;
using MVCTEST.Services.Frontend_MVC.Services;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
using System;

namespace MVCTEST.Services
{
    public class UsuarioService
    {
        private readonly ApiService _apiService;

        public UsuarioService(ApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<UsuarioSesion?> ValidarUsuario(string usuario, string contrasena)
        {
            var response = await _apiService.GetAsync<List<EmpleadoDto>>("empleados");

            if (response == null)
            {
                Console.WriteLine("⚠️ La respuesta es null.");
                return null;
            }

            if (!response.Success)
            {
                Console.WriteLine("⚠️ La respuesta no fue exitosa.");
                return null;
            }

            if (response.Data == null || !response.Data.Any())
            {
                Console.WriteLine("⚠️ No se recibieron empleados.");
                return null;
            }

            // Debug: mostrar empleados
            foreach (var emp in response.Data)
            {
                Console.WriteLine($"➡️ Usuario DB: '{emp.Usuario}' | Contrasena DB: '{emp.ContrasenaHash}'");
            }

            // Comparación directa sin hash
            var empleado = response.Data.FirstOrDefault(e =>
                e.Usuario == usuario && e.ContrasenaHash == contrasena);

            if (empleado == null)
            {
                Console.WriteLine($"❌ No se encontró empleado con usuario '{usuario}' y contraseña proporcionada.");
                return null;
            }

            Console.WriteLine($"✅ Usuario válido: {empleado.Usuario}");

            return new UsuarioSesion
            {
                Usuario = empleado.Usuario,
                Rol = empleado.Rol,
                Nombre = $"{empleado.Nombre} {empleado.Apellido}"
            };
        }
    }
}
