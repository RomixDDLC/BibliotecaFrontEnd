﻿using MVCTEST.Models;
using System.Net.Http;
using System.Net.Http.Json;

namespace MVCTEST.Services
{
    public class EmpleadoService
    {
        private readonly HttpClient _http;

        public EmpleadoService(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<EmpleadoDto>> ObtenerEmpleados()
        {
            return await _http.GetFromJsonAsync<List<EmpleadoDto>>("empleados");
        }

        public async Task<EmpleadoDto?> ObtenerEmpleadoPorId(int id)
        {
            return await _http.GetFromJsonAsync<EmpleadoDto>($"empleados/{id}");
        }

        public async Task<bool> CrearEmpleado(EmpleadoDto dto)
        {
            var response = await _http.PostAsJsonAsync("empleados", dto);
            return response.IsSuccessStatusCode;
        }


        public async Task<bool> ActualizarEmpleado(int id, EmpleadoDto dto)
        {
            var response = await _http.PutAsJsonAsync($"empleados/{id}", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarEmpleado(int id)
        {
            var response = await _http.DeleteAsync($"empleados/{id}");
            return response.IsSuccessStatusCode;
        }

    }
}
