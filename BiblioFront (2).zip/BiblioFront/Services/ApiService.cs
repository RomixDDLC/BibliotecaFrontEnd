﻿namespace MVCTEST.Services
{
    using System.Net.Http;
    using System.Net.Http.Json;
    using System.Threading.Tasks;
    using MVCTEST.Models;

    namespace Frontend_MVC.Services
    {
        public class ApiService
        {
            private readonly HttpClient _httpClient;

            public ApiService(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }

            public async Task<ApiResponse<T>> GetAsync<T>(string url)
            {
                var response = await _httpClient.GetAsync(url);
                var result = await response.Content.ReadFromJsonAsync<ApiResponse<T>>();
                return result!;
            }

            public async Task<ApiResponse<T>> PostAsync<T, TData>(string url, TData data)
            {
                var response = await _httpClient.PostAsJsonAsync(url, data);
                var result = await response.Content.ReadFromJsonAsync<ApiResponse<T>>();
                return result!;
            }

            public async Task<ApiResponse<T>> PutAsync<T, TData>(string url, TData data)
            {
                var response = await _httpClient.PutAsJsonAsync(url, data);
                var result = await response.Content.ReadFromJsonAsync<ApiResponse<T>>();
                return result!;
            }

            public async Task<bool> DeleteAsync(string url)
            {
                var response = await _httpClient.DeleteAsync(url);
                return response.IsSuccessStatusCode;
            }
        }
    }

}
