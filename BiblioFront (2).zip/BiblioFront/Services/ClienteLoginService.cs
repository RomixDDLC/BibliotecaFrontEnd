﻿using MVCTEST.Models;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace MVCTEST.Services.Frontend_MVC.Services
{
    public class ClienteLoginService
    {
        private readonly HttpClient _httpClient;

        public ClienteLoginService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // Método para validar cliente por correo y teléfono
        public async Task<ClienteDto> ValidarClienteAsync(string correo, string telefono)
        {
            // Suponiendo que tu API backend tiene un endpoint para validar clientes, por ejemplo:
            // GET api/clientes/validar?correo=xxx&telefono=yyy

            var response = await _httpClient.GetAsync($"clientes/validar?correo={correo}&telefono={telefono}");

            if (response.IsSuccessStatusCode)
            {
                var cliente = await response.Content.ReadFromJsonAsync<ClienteDto>();
                return cliente;
            }

            return null;
        }
    }
}
