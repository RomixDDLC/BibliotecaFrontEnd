﻿using MVCTEST.Models;
using System.Net.Http.Json;

namespace MVCTEST.Services
{
    public class PrestamoService
    {
        private readonly HttpClient _httpClient;

        public PrestamoService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<PrestamoDto>> ObtenerPrestamosPorCliente(int clienteId)
        {
            var response = await _httpClient.GetAsync($"prestamos/cliente/{clienteId}");
            if (response.IsSuccessStatusCode)
            {
                var prestamos = await response.Content.ReadFromJsonAsync<List<PrestamoDto>>();
                return prestamos ?? new List<PrestamoDto>();
            }
            return new List<PrestamoDto>();
        }

        public async Task<List<PrestamoDto>> ObtenerPrestamos()
        {
            var response = await _httpClient.GetAsync("prestamos");
            if (response.IsSuccessStatusCode)
            {
                var prestamos = await response.Content.ReadFromJsonAsync<List<PrestamoDto>>();
                return prestamos ?? new List<PrestamoDto>();
            }
            return new List<PrestamoDto>();
        }

        public async Task<PrestamoDto?> ObtenerPrestamoPorId(int id)
        {
            return await _httpClient.GetFromJsonAsync<PrestamoDto>($"prestamos/{id}");
        }

        public async Task<bool> CrearPrestamo(PrestamoCreateDto dto)
        {
            var response = await _httpClient.PostAsJsonAsync("prestamos", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarPrestamo(int id)
        {
            var response = await _httpClient.DeleteAsync($"prestamos/{id}");
            return response.IsSuccessStatusCode;
        }
        public async Task<bool> ActualizarPrestamo(PrestamoDto dto)
        {
            var response = await _httpClient.PutAsJsonAsync($"prestamos/{dto.PrestamoID}", dto);
            return response.IsSuccessStatusCode;
        }

    }
}
