﻿using MVCTEST.Models;
using System.Net.Http.Json;

namespace MVCTEST.Services
{
    public class EntregaService
    {
        private readonly HttpClient _httpClient;

        public EntregaService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<EntregaDto>> ObtenerEntregas()
        {
            var response = await _httpClient.GetAsync("Entregas");
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<EntregaDto>>();
        }

        public async Task<bool> CrearEntrega(EntregaCreateDto dto)
        {
            var response = await _httpClient.PostAsJsonAsync("Entregas", dto);
            return response.IsSuccessStatusCode;
        }
        public async Task<EntregaDto?> ObtenerEntregaPorId(int id)
        {
            return await _httpClient.GetFromJsonAsync<EntregaDto>($"entregas/{id}");
        }
        public async Task<bool> ActualizarEntrega(EntregaDto dto)
        {
            var response = await _httpClient.PutAsJsonAsync($"entregas/{dto.EntregaID}", dto);
            return response.IsSuccessStatusCode;
        }
        public async Task<bool> EliminarEntrega(int id)
        {
            var respuesta = await _httpClient.DeleteAsync($"entregas/{id}");
            return respuesta.IsSuccessStatusCode;
        }


    }
}
