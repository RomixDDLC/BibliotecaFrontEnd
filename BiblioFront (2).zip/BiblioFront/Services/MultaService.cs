﻿using MVCTEST.Models;
using System.Net.Http.Json;

namespace MVCTEST.Services
{
    public class MultaService
    {
        private readonly HttpClient _httpClient;

        public MultaService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<MultaDto>> ObtenerMultas()
        {
            return await _httpClient.GetFromJsonAsync<List<MultaDto>>("multas") ?? new List<MultaDto>();
        }

        public async Task<bool> CrearMulta(MultaDto dto)
        {
            var response = await _httpClient.PostAsJsonAsync("multas", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<MultaDto?> ObtenerMultaPorId(int id)
        {
            return await _httpClient.GetFromJsonAsync<MultaDto>($"multas/{id}");
        }

        public async Task<bool> ActualizarMulta(int id, MultaDto dto)
        {
            var response = await _httpClient.PutAsJsonAsync($"multas/{id}", dto);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> EliminarMulta(int id)
        {
            var response = await _httpClient.DeleteAsync($"multas/{id}");
            return response.IsSuccessStatusCode;
        }
    }
}
