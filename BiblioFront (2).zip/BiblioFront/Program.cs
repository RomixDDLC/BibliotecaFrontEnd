﻿using System;
using MVCTEST.Services;
using MVCTEST.Services.Frontend_MVC.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Agrega servicios MVC y Razor
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

// Soporte para sesiones
builder.Services.AddDistributedMemoryCache(); // Sesión en memoria
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Registrar servicios personalizados
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<ApiService>();

// Dirección base del backend (API)
var backendBaseUrl = "https://localhost:7074/api/";

// HTTP clients para cada servicio
builder.Services.AddHttpClient<ClienteService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddHttpClient<EmpleadoService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddHttpClient<LibroService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddHttpClient<MultaService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddHttpClient<EntregaService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddHttpClient<PrestamoService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddHttpClient<ClienteLoginService>(client =>
{
    client.BaseAddress = new Uri(backendBaseUrl);
});
builder.Services.AddSingleton<ITokenProvider, TokenProvider>();

var app = builder.Build();

// Middleware de error y seguridad
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// **Importante**: Session debe ir antes de Authentication/Authorization
app.UseSession();

app.UseAuthorization();

// Rutas MVC por convención: /{controller=Home}/{action=Index}/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

// Mapea Razor Pages si las usas
app.MapRazorPages();

app.Run();
