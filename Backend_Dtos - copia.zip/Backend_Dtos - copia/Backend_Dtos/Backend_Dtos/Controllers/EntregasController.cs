﻿using Backend_Dtos.Dtos;
using Backend_Dtos.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend_Dtos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntregasController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public EntregasController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Entrega>>> GetEntregas()
        {
            return await _context.Entregas.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Entrega>> GetEntrega(int id)
        {
            var entrega = await _context.Entregas.FindAsync(id);
            if (entrega == null) return NotFound();
            return entrega;
        }

        [HttpPost]
        public async Task<ActionResult<Entrega>> PostEntrega(EntregaCreateDto dto)
        {
            var entrega = new Entrega
            {
                MetodoEntrega = dto.MetodoEntrega
            };

            _context.Entregas.Add(entrega);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEntrega), new { id = entrega.EntregaID }, entrega);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutEntrega(int id, EntregaCreateDto dto)
        {
            var entrega = await _context.Entregas.FindAsync(id);
            if (entrega == null) return NotFound();

            entrega.MetodoEntrega = dto.MetodoEntrega;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEntrega(int id)
        {
            var entrega = await _context.Entregas.FindAsync(id);
            if (entrega == null) return NotFound();

            _context.Entregas.Remove(entrega);
            await _context.SaveChangesAsync();
            return NoContent();
        }

    }
}
