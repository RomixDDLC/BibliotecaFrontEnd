﻿namespace Backend_Dtos.Controllers
{
    using Backend_Dtos.Dtos;
    using Backend_Dtos.Models;
    using BibliotecaApi.Dtos;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    [Route("api/[controller]")]
    [ApiController]
    public class ClientesController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public ClientesController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cliente>>> GetClientes()
        {
            return await _context.Clientes.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Cliente>> GetCliente(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);
            if (cliente == null) return NotFound();
            return cliente;
        }

        [HttpPost]
        public async Task<ActionResult<Cliente>> PostCliente(ClienteCreateDto dto)
        {
            var cliente = new Cliente
            {
                Nombre = dto.Nombre,
                Apellido = dto.Apellido,
                Correo = dto.Correo,
                Telefono = dto.Telefono,
                Direccion = dto.Direccion,
                FechaRegistro = DateTime.Now
            };

            _context.Clientes.Add(cliente);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCliente), new { id = cliente.ClienteID }, cliente);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutCliente(int id, ClienteCreateDto dto)
        {
            var cliente = await _context.Clientes.FindAsync(id);
            if (cliente == null) return NotFound();

            cliente.Nombre = dto.Nombre;
            cliente.Apellido = dto.Apellido;
            cliente.Correo = dto.Correo;
            cliente.Telefono = dto.Telefono;
            cliente.Direccion = dto.Direccion;
            cliente.FechaRegistro = dto.FechaRegistro;

            _context.Entry(cliente).State = EntityState.Modified;

            try { await _context.SaveChangesAsync(); }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Clientes.Any(e => e.ClienteID == id)) return NotFound();
                throw;
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCliente(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);
            if (cliente == null) return NotFound();

            _context.Clientes.Remove(cliente);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpGet("validar")]
        public async Task<ActionResult<ClienteDto>> ValidarCliente([FromQuery] string correo, [FromQuery] string telefono)
        {
            if (string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(telefono))
                return BadRequest("Correo y teléfono son requeridos.");

            var cliente = await _context.Clientes
                .Where(c => c.Correo == correo && c.Telefono == telefono)
                .Select(c => new ClienteDto
                {
                    Id = c.ClienteID,
                    Nombre = c.Nombre,
                    Correo = c.Correo,
                    Telefono = c.Telefono
                    // agrega otros campos que quieras exponer
                })
                .FirstOrDefaultAsync();

            if (cliente == null)
                return NotFound("Cliente no encontrado o credenciales incorrectas.");

            return Ok(cliente);
        }

    }
}
