﻿using Backend_Dtos.Dtos;
using Backend_Dtos.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend_Dtos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MultasController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public MultasController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Multa>>> GetMultas()
        {
            return await _context.Multas.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Multa>> GetMulta(int id)
        {
            var multa = await _context.Multas.FindAsync(id);
            if (multa == null) return NotFound();
            return multa;
        }

        [HttpPost]
        public async Task<ActionResult<Multa>> PostMulta(MultaCreateDto dto)
        {
            var multa = new Multa
            {
                DiasAtraso = dto.DiasAtraso,
                PrecioPorDia = dto.PrecioPorDia
            };

            _context.Multas.Add(multa);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetMulta), new { id = multa.MultaID }, multa);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutMulta(int id, MultaCreateDto dto)
        {
            var multa = await _context.Multas.FindAsync(id);
            if (multa == null) return NotFound();

            multa.DiasAtraso = dto.DiasAtraso;
            multa.PrecioPorDia = dto.PrecioPorDia;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMulta(int id)
        {
            var multa = await _context.Multas.FindAsync(id);
            if (multa == null) return NotFound();

            _context.Multas.Remove(multa);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
