﻿using Backend_Dtos.Dtos;
using Backend_Dtos.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend_Dtos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibrosController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public LibrosController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Libro>>> GetLibros()
        {
            return await _context.Libros.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Libro>> GetLibro(int id)
        {
            var libro = await _context.Libros.FindAsync(id);
            if (libro == null) return NotFound();
            return libro;
        }

        [HttpPost]
        public async Task<ActionResult<Libro>> PostLibro(LibroCreateDto dto)
        {
            var libro = new Libro
            {
                Titulo = dto.Titulo,
                Autor = dto.Autor,
                Editorial = dto.Editorial,
                ISBN = dto.Isbn,
                AñoPublicacion = dto.AñoPublicacion,
                Genero = dto.Genero,
                EjemplaresDisponibles = dto.EjemplaresDisponibles
            };

            _context.Libros.Add(libro);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetLibro), new { id = libro.LibroID }, libro);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutLibro(int id, LibroCreateDto dto)
        {
            var libro = await _context.Libros.FindAsync(id);
            if (libro == null) return NotFound();

            libro.Titulo = dto.Titulo;
            libro.Autor = dto.Autor;
            libro.Editorial = dto.Editorial;
            libro.ISBN = dto.Isbn;
            libro.AñoPublicacion = dto.AñoPublicacion;
            libro.Genero = dto.Genero;
            libro.EjemplaresDisponibles = dto.EjemplaresDisponibles;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLibro(int id)
        {
            var libro = await _context.Libros.FindAsync(id);
            if (libro == null) return NotFound();

            _context.Libros.Remove(libro);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        [HttpGet("disponibles")]
        public async Task<ActionResult<IEnumerable<Libro>>> GetLibrosDisponibles()
        {
            var disponibles = await _context.Libros
                .Where(l => l.EjemplaresDisponibles > 0)
                .ToListAsync();

            return Ok(disponibles);
        }

    }
}
