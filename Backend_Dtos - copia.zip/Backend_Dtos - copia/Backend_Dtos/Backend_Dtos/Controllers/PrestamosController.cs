﻿using Backend_Dtos.Dtos;
using Backend_Dtos.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend_Dtos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrestamosController : ControllerBase
    {
        private readonly BibliotecaContext _context;

        public PrestamosController(BibliotecaContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PrestamoReadDto>>> GetPrestamos()
        {
            var prestamos = await _context.Prestamos
                .Include(p => p.Libro)
                .Include(p => p.Cliente)
                .Include(p => p.Empleado)
                .Select(p => new PrestamoReadDto
                {
                    PrestamoID = p.PrestamoID,
                    ClienteID = p.ClienteID,
                    EmpleadoID = p.EmpleadoID,
                    LibroID = p.LibroID,
                    FechaPrestamo = p.FechaPrestamo,
                    FechaLimite = p.FechaLimite,
                    FechaDevuelto = p.FechaDevuelto,
                    Estado = p.Estado,
                    TotalMulta = p.TotalMulta,
                    MultaID = p.MultaID,
                    EntregaID = p.EntregaID,
                    ClienteNombre = p.Cliente.Nombre + " " + p.Cliente.Apellido,
                    LibroTitulo = p.Libro.Titulo,
                    EmpleadoNombre = p.Empleado.Nombre + " " + p.Empleado.Apellido
                })
                .ToListAsync();

            return Ok(prestamos);
        }



        [HttpGet("{id}")]
        public async Task<ActionResult<Prestamo>> GetPrestamo(int id)
        {
            var prestamo = await _context.Prestamos
                .Include(p => p.Cliente)
                .Include(p => p.Empleado)
                .Include(p => p.Libro)
                .Include(p => p.Multa)
                .Include(p => p.Entrega)
                .FirstOrDefaultAsync(p => p.PrestamoID == id);

            if (prestamo == null) return NotFound();
            return prestamo;
        }

        [HttpPost]
        public async Task<ActionResult<Prestamo>> PostPrestamo(PrestamoCreateDto dto)
        {
            var prestamo = new Prestamo
            {
                LibroID = dto.LibroID,
                ClienteID = dto.ClienteID,
                EmpleadoID = dto.EmpleadoID,
                FechaPrestamo = dto.FechaPrestamo,
                FechaLimite = dto.FechaLimite,
                FechaDevuelto = dto.FechaDevuelto,
                Estado = dto.Estado,
                TotalMulta = dto.TotalMulta,
                MultaID = dto.MultaID,
                EntregaID = dto.EntregaID
            };

            _context.Prestamos.Add(prestamo);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetPrestamo), new { id = prestamo.PrestamoID }, prestamo);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutPrestamo(int id, PrestamoCreateDto dto)
        {
            var prestamo = await _context.Prestamos.FindAsync(id);
            if (prestamo == null) return NotFound();

            prestamo.LibroID = dto.LibroID;
            prestamo.ClienteID = dto.ClienteID;
            prestamo.EmpleadoID = dto.EmpleadoID;
            prestamo.FechaPrestamo = dto.FechaPrestamo;
            prestamo.FechaLimite = dto.FechaLimite;
            prestamo.FechaDevuelto = dto.FechaDevuelto;
            prestamo.Estado = dto.Estado;
            prestamo.TotalMulta = dto.TotalMulta;
            prestamo.MultaID = dto.MultaID;
            prestamo.EntregaID = dto.EntregaID;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePrestamo(int id)
        {
            var prestamo = await _context.Prestamos.FindAsync(id);
            if (prestamo == null) return NotFound();

            _context.Prestamos.Remove(prestamo);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
