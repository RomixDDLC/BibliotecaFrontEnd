﻿using Backend_Dtos.Models;

public class Empleado
{
    public int EmpleadoID { get; set; }
    public string Nombre { get; set; }
    public string Apellido { get; set; }
    public string Usuario { get; set; }
    public string ContrasenaHash { get; set; }
    public string Rol { get; set; }
    public DateTime FechaIngreso { get; set; }

    public ICollection<Prestamo> Prestamos { get; set; }
}
