﻿namespace Backend_Dtos.Models
{
    public class Entrega
    {
        public int EntregaID { get; set; }
        public string MetodoEntrega { get; set; }

        public ICollection<Prestamo> Prestamos { get; set; }
    }

}
