﻿namespace Backend_Dtos.Models
{
    using Microsoft.EntityFrameworkCore;

    public class BibliotecaContext : DbContext
    {
        public BibliotecaContext(DbContextOptions<BibliotecaContext> options) : base(options) { }

        public DbSet<Libro> Libros { get; set; }
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Empleado> Empleados { get; set; }
        public DbSet<Entrega> Entregas { get; set; }
        public DbSet<Multa> Multas { get; set; }
        public DbSet<Prestamo> Prestamos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Libro)
                .WithMany(l => l.Prestamos)
                .HasForeignKey(p => p.LibroID);

            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Cliente)
                .WithMany(c => c.Prestamos)
                .HasForeignKey(p => p.ClienteID);

            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Empleado)
                .WithMany(e => e.Prestamos)
                .HasForeignKey(p => p.EmpleadoID);

            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Multa)
                .WithMany(m => m.Prestamos)
                .HasForeignKey(p => p.MultaID);

            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Entrega)
                .WithMany(e => e.Prestamos)
                .HasForeignKey(p => p.EntregaID);
        }
    }

}
