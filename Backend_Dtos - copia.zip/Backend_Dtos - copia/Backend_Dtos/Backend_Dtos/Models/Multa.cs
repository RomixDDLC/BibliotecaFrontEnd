﻿namespace Backend_Dtos.Models
{
    public class Multa
    {
        public int MultaID { get; set; }
        public int DiasAtraso { get; set; }
        public decimal PrecioPorDia { get; set; }

        public ICollection<Prestamo> Prestamos { get; set; }
    }

}
