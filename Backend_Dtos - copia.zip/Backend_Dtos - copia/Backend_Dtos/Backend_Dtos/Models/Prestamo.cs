﻿namespace Backend_Dtos.Models
{
    public class Prestamo
    {
        public int PrestamoID { get; set; }

        public int LibroID { get; set; }
        public Libro Libro { get; set; }

        public int ClienteID { get; set; }
        public Cliente Cliente { get; set; }

        public int EmpleadoID { get; set; }
        public Empleado Empleado { get; set; }

        public DateTime FechaPrestamo { get; set; }
        public DateTime FechaLimite { get; set; }
        public DateTime? FechaDevuelto { get; set; }
        public string? Estado { get; set; }

        public decimal? TotalMulta { get; set; }

        public int? MultaID { get; set; }
        public Multa Multa { get; set; }

        public int? EntregaID { get; set; }
        public Entrega Entrega { get; set; }
    }

}
