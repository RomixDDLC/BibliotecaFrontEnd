﻿namespace Backend_Dtos.Models
{
    public class Puestos
    {
        public int ID_Puesto { get; set; }

        public string Descripcion_Puesto { get; set; }

        public bool Activo { get; set; }
    }
}
