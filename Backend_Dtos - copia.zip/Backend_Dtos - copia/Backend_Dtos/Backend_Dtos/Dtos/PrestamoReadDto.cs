﻿namespace Backend_Dtos.Dtos
{
    public class PrestamoReadDto
    {
        public int PrestamoID { get; set; }
        public int ClienteID { get; set; }
        public int EmpleadoID { get; set; }
        public int LibroID { get; set; }
        public DateTime FechaPrestamo { get; set; }
        public DateTime FechaLimite { get; set; }
        public DateTime? FechaDevuelto { get; set; }
        public string Estado { get; set; }
        public decimal? TotalMulta { get; set; } // ✅ NULLABLE
        public int? MultaID { get; set; }
        public int? EntregaID { get; set; }

        public string ClienteNombre { get; set; }
        public string LibroTitulo { get; set; }
        public string EmpleadoNombre { get; set; }
    }
}
