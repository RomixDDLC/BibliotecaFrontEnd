﻿namespace Backend_Dtos.Dtos
{
    public class EntregaCreateDto
    {
        public string MetodoEntrega { get; set; }
    }
}
