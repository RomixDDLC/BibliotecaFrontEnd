﻿namespace Backend_Dtos.Dtos
{
    public class LibroCreateDto
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Editorial { get; set; }
        public string Isbn { get; set; }
        public int AñoPublicacion { get; set; }
        public string Genero { get; set; }
        public int EjemplaresDisponibles { get; set; }
    }
}
