﻿namespace Backend_Dtos.Dtos
{
    public class MultaCreateDto
    {
        public int DiasAtraso { get; set; }
        public decimal PrecioPorDia { get; set; }
    }
}
